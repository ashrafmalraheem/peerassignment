/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file: stat.c
 * @brief: Computes few statistics on given data set
 *
 * The file contains defintion of functions that can be used to calculate
 * statistics like minimum, maximum, mean, median, etc, on a given data set.
 *
 * @author: Sivasundar KS
 * @date: 31-Oct-2018
 *
 */


#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

static int partition (unsigned char arr[], int low, int high);
static void quickSort(unsigned char arr[], int low, int high);

/*
 * A function that prints the statistics of an array including minimum, maximum,
 * mean, and median.
 */
void print_statistics(unsigned char *test_arr, size_t size)
{
  if (test_arr == NULL) {
    PRINTF("Error! Input array is NULL\n");
    return;
  }

  if (size < 1) {
    PRINTF("Error! Input array has no elements\n");
    return;
  }

  PRINTF("maximum : %d ", find_maximum(test_arr, size));
  PRINTF("minimum : %u ", find_minimum(test_arr, size));
  PRINTF("mean    : %d ", find_mean(test_arr, size));
  PRINTF("median  : %d\n", find_median(test_arr, size));
}

/*
 * Given an array of data and a length, prints the array to the screen
 */
void print_array(unsigned char *test_arr, size_t size)
{

#if defined (VERBOSE)
  int i = 0;

  if (test_arr == NULL) {
    PRINTF("Error! Input array is NULL\n");
    return;
  }

  if (size < 1) {
    PRINTF("Error! Input array has no elements\n");
    return;
  }

  while (i < size) {
    /* prints 8 elements in a line */
    if ((i & 0x7) == 0) {
      if (i > 0) {
	PRINTF("\n");
      }
      PRINTF("(%.2d - %.2d) :: ", i, (i + 0x7));
    }

    PRINTF("%4d ", test_arr[i]);
    i++;
  }
  PRINTF("\n");

#endif  
}

/*
 * Given an array of data and a length, returns the median value
 */
unsigned char find_median(unsigned char *test_arr, size_t size)
{

  int mid = (size - 1) / 2;
  unsigned char median = 0;

  if (test_arr == NULL) {
    PRINTF("Error! Input array is NULL\n");
    return (-1);
  }

  if (size < 1) {
    PRINTF("Error! Input array has no elements\n");
    return (-2);
  }

  /* Sort the array before finding median */
  sort_array(test_arr, size);

  /* Check if the lenght of array is odd or even */
  if (size & 0x1) {
    median = test_arr[mid];
  } else {
    median = (test_arr[mid] + test_arr[mid+1]) / 2;
  }

  return (median);
}

/*
 * Given an array of data and a length, returns the mean
 */
unsigned char find_mean(unsigned char *test_arr, size_t size)
{
  unsigned int sum = 0;
  int i = 0;

  if (test_arr == NULL) {
    PRINTF("Error! Input array is NULL\n");
    return (-1);
  }

  if (size < 1) {
    PRINTF("Error! Input array has no elements\n");
    return (-2);
  }

  for (; i < size; i++) {
    sum += test_arr[i];
  }

  return (sum / size);
}

/*
 * Given an array of data and a length, returns the maximum
 */
unsigned char find_maximum(unsigned char *test_arr, size_t size)
{
  int i = 1;
  unsigned char max;

  if (test_arr == NULL) {
    PRINTF("Error! Input array is NULL\n");
    return (-1);
  }

  if (size < 1) {
    PRINTF("Error! Input array has no elements\n");
    return (-2);
  }

  max = test_arr[0];

  for (; i < size; i++) {
    if (max < test_arr[i]) {
      max = test_arr[i];
    }
  }

  return (max);
}

/*
 * Given an array of data and a length, returns the minimum
 */
unsigned char find_minimum(unsigned char *test_arr, size_t size)
{
  int i = 1;
  unsigned char min;

  if (test_arr == NULL) {
    PRINTF("Error! Input array is NULL\n");
    return (-1);
  }

  if (size < 1) {
    PRINTF("Error! Input array has no elements\n");
    return (-2);
  }

  min = test_arr[0];

  for (; i < size; i++) {
    if (min > test_arr[i]) {
      min = test_arr[i];
    }
  }

  return (min);
}

/*
 * Given an array of data and a length, sorts the array from largest to
 * smallest.
 */
void sort_array(unsigned char *test_arr, size_t size)
{
  if (test_arr == NULL) {
    PRINTF("Error! Input array is NULL\n");
    return;
  }

  if (size < 1) {
    PRINTF("Error! Input array has no elements\n");
    return;
  }

  quickSort(test_arr, 0, size -1);
}

static int partition (unsigned char arr[], int low, int high)
{
  unsigned char pivot = arr[high];    // pivot
  int i = (low - 1);  // Index of smaller element
  unsigned char temp = 0;

  for (int j = low; j <= high- 1; j++) {

      /* If current element is greater than or equal to pivot */
      if (arr[j] >= pivot) {
        i++;    /* increment index of smaller element */

	/* Swap arr[i] and arr[j] */
        temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
      }
  }

  /* swap pivot with the position of the element, i+1 in the array */
  temp = arr[i+1];
  arr[i+1] = arr[high];
  arr[high] = temp;

  return (i + 1);
}

/* The main function that implements QuickSort */
static void quickSort(unsigned char arr[], int low, int high)
{
  if (low < high) {
    /* pi is partitioning index, arr[p] is now at right place */
    int pi = partition(arr, low, high);

    /* Sort elements before partition and after partition */
    quickSort(arr, low, pi - 1);
    quickSort(arr, pi + 1, high);
  }
}
