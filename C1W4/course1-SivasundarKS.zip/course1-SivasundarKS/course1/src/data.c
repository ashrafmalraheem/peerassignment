
/******************************************************************************
 * Copyright (C) 2018 by Sivasundar KS
 *
 * Developed as part of Embedded software assessment. Other deveopers are free
 * to use and enhace these Code. The developer is not liable for any misuse of
 * this material. 
 *
 *****************************************************************************/
/**
 * @file data.c
 * @brief Implementation containing numeric manipulations
 *
 * This file contains implementation that manipulates data from integer
 * to ASCII and vise versa
 *
 * @author Sivasundar KS	
 * @date Novemeber 17 2018
 *
 */
#include "memory.h"
#include "data.h"

uint8_t my_itoa(int32_t data, uint8_t * ptr, uint32_t base)
{
	uint8_t buffer[100] = {0}; 
	uint8_t *str = &(buffer[99]); // Point to LSB
	int num_of_digits = 1; 
	int isNegative = 0; 

	*str-- = '\0'; // Set NULL string terminator at the end

	// Test for negative number
	if (data < 0 && base == 10) 
	{ 
		isNegative = 1; 
		data = -data; 
	} 

	// Process individual digits 
	do {
		*str-- = "0123456789abcdef"[data % base]; 
		data = data/base;
		num_of_digits++;
	} while (data != 0);

	// If number is negative, insert '-' sign
	if (isNegative) {
		*str-- = '-'; 
		num_of_digits++;
	}

	// Copy the data from buffer to ptr
	my_memcopy(str+1, ptr, num_of_digits);

	--num_of_digits; // Exclude Null Terminator
	return (num_of_digits);
}	

int32_t my_atoi(uint8_t * ptr, uint8_t digits, uint32_t base)
{
	int8_t sign = 1, value;
	uint32_t weighted_value = 0;


	if (!ptr) {
		return (0);
	}

	/* Remove '+/-' signs from string */
	if (*ptr == '-') {
		sign = -1;
		ptr++;
	}

	if (*ptr == '+') {
		ptr++;
	}

	/* Process the string until null terminator is reached */
	while (isAplhaNum(*ptr)) {

		value = isDigit(*ptr) ? *ptr - '0' : 10 + (*ptr - 'a');

		// check for base error
		if (value > base) {
			return (0);
		}

		weighted_value = base * weighted_value + value;

		ptr++;
	}

	return (sign * weighted_value);
}
