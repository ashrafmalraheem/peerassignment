/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h
 * @brief Header file contains statistics functions
 *
 * This file contains declaration of a suite of functions that are used to
 * perform statistical analysis on the given data set.
 *
 * @author Sivasundar KS
 * @date 1-NOV-2018
 *
 */
#ifndef __STATS_H__
#define __STATS_H__

#include <stdlib.h>
#include "platform.h"

/**
 * @brief Prints the statistics of the array
 *
 * This function prints the consolidated statistics like min, max,
 * mean and median of the given array
 *
 * @param test_arr - input data set in an array of unsigned char
 * @param size - number of elements in the input array
 *
 * @return - Nothing
 */
void print_statistics(unsigned char *test_arr, size_t size);

/**
 * @brief Prints all the elements in an array
 *
 * This function prints all the elements in the given input array
 *
 * @param test_arr - input data set in an array of unsigned char
 * @param size - number of elements in the input array
 *
 * @return - Nothing
 */
void print_array(unsigned char *test_arr, size_t size);

/**
 * @brief Finds median of the elements
 *
 * This is a function to find the median of elements present in the
 * given array. This function permanently modifies the input array
 * so that all the elements sorted in descending order.
 *
 * @param test_arr - input data set in an array of unsigned char
 * @param size - number of elements in the input array
 *
 * @return Median value of the array, rounded down to nearest integer
 */
unsigned char find_median(unsigned char *test_arr, size_t size);

/**
 * @brief Finds mean of the elements
 *
 * This is a function to find the mean of elements present in the
 * given array.
 *
 * @param test_arr - input data set in an array of unsigned char
 * @param size - number of elements in the input array
 *
 * @return mean value of the array, rounded down to nearest integer
 */
unsigned char find_mean(unsigned char *teat_arr, size_t size);

/**
 * @brief Finds the maximum in an array of elements
 *
 * This function is used to find the maximum value in the given
 * array of numbers.
 *
 * @param test_arr - input data set in an array of unsigned char
 * @param size - number of elements in the input array
 *
 * @return maximum value in the array
 */
unsigned char find_maximum(unsigned char *teat_arr, size_t size);

/**
 * @brief Finds minimum in an array of elements
 *
 * This function can be used to get the minimum value in the given
 * array of numbers.
 *
 * @param test_arr - input data set in an array of unsigned char
 * @param size - number of elements in the input array
 *
 * @return minimum value in the array
 */
unsigned char find_minimum(unsigned char *teat_arr, size_t size);

/**
 * @brief Sorts the input array
 *
 * This function is used to sort the array elements in descending order.
 * The function in turn uses quick sort technique, which is a in-place
 * sorting and hence modifies the input array permanently.
 *
 * @param test_arr - input data set in an array of unsigned char
 * @param size - number of elements in the input array
 *
 * @return Nothing
 */
void sort_array(unsigned char *teat_arr, size_t size);

#endif /* __STATS_H__ */
