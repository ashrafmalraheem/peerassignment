/******************************************************************************
 * Copyright (C) 2018 by Sivasundar KS
 *
 * Developed as part of Embedded software assessment. Other deveopers are free
 * to use and enhace these Code. The developer is not liable for any misuse of
 * this material. 
 *
 *****************************************************************************/
/**
 * @file data.h
 * @brief Abstraction containing numeric manipulations
 *
 * This header file provides an abstraction of manipulating data from integer
 * to ASCII and vise versa
 *
 * @author Sivasundar KS	
 * @date Novemeber 17 2018
 *
 */
#ifndef __DATA_H__
#define __DATA_H__

/* Utility Macro definition */
#define isAplhaNum(x) (((x >= '0') && (x <= '9')) || ((x >= 'a') && (x <= 'f'))) 
#define isDigit(x) ((x >= '0') && (x <= '9'))
#define INT_MAXI ((1 << 31) - 1)

#define BASE_2 2
#define BASE_4 4
#define BASE_8 8
#define BASE_10 10
#define BASE_16 16

/**
 * @brief Converts a integer value to ASCII string 
 *
 * Given a signed integer and base, this function will convert it to the ASCII
 * string specfied by the pointer to a char data set
 *
 * @param data signed Integer Value (Input)
 * @param ptr Pointer to ASCII string
 * @param base base of the number system to be converted
 *
 * @return
 *    Number of ASCII Characters that represents the data
 */
uint8_t my_itoa(int32_t data, uint8_t * ptr, uint32_t base);

/**
 * @brief Converts ASCII string to integer value
 *
 * Given a pointer to a char data set, this will set a provided
 * index into that data set to the value provided.
 *
 * @param ptr Pointer to ASCII string that represents Integer value
 * @param digits Number of ASCII character in the string
 * @param base Base of the Number system the string represent
 *
 * @return
 *    Resultant Signed Integer value
 */
int32_t my_atoi(uint8_t * ptr, uint8_t digits, uint32_t base);



#endif /* __DATA_H__ */
