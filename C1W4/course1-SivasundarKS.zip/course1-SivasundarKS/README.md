//*
 * @authour: Sivasundar KS is an IOT enthusiast and Embedded Developer
 * @project: This is a Final assessment Submission
 * Source code can be found in https://github.com/Sivasundar1130/Embedded_Sys_univ_of_colorado_boulder/Assessments.git
 * 
 *
 * Added data.c/data.h files in Sources and Include directories
 * Enhanced memory.c/memory.h files to include memory manipulations
 * Updated Makefile to build for new source hirerachy.
 * All the intermediate and binaries will generated in parent folder where the makefile is present.
 *
 * Example usage:
 *    make build PLATFORM=HOST SIMULATE=COURSE1 DEBUG=VERBOSE
 *    make clean
 *    make compile-all PLATFORM=HOST SIMULATE=COURSE1 DEBUG=VERBOSE
 *    make clean
 *    make memory.o PLATFORM=HOST SIMULATE=COURSE1 DEBUG=VERBOSE
 *    make data.i PLATFORM=MSP432 SIMULATE=COURSE1 DEBUG=VERBOSE
 *    make data.asm PLATFORM=HOST SIMULATE=COURSE1 DEBUG=VERBOSE
 *    make clean
 *    make build PLATFORM=MSP432 SIMULATE=COURSE1 DEBUG=VERBOSE
 *
 *//
