/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file:    stats.c 
 * @brief:   This file holds the source code for a stastics
             program to calculate stastics of an char array
             the array values need not be unique.
             the char arry element is one byte and must limit its
             value to 255
             
             


 * <functions: void main() driver for testing
               void print_stastics(int min, int max, int mean, int median) 
                    -- function to print results

               void print_array(char array[]) 
                    --function to print an array

               void sort_array(char Array[], int LENGTH); 
                    --sorts an array in desencing order

               char find_median(char array[], int LENGTH) 
                    --the return value is the calculated median

               char find_maximum(char array[], int LENGTH) 
                    -- the return value is the maximum

               char find_minimum(char array[], int LENGTH)
                     --returns the minimum value

               char find_mean(char array[], int LENGTH)  
                    -- calculates  and returns the mean value 
                       (standard average) of the array
 
 *to imporve searches the sorting function will be 
  performed first in place in memory to improve
  the efficiency of the median, minimum and maximum functions
 *
 *
 * @author:   William  Hays
 * @date:     Aug 4, 2018
 */

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include "../include/common/stats.h"
#include "../include/common/platform.h"
#include <stdlib.h>




/* Add other Implementation File Code Here */


//sorts an array in deseding order with Quick Sort
//input -- char array and its length
//return value -- ponter to sorted array
unsigned char *sort_array(unsigned char charArray[], int length){

    int start = 0;
    quick_sort(charArray, start, length -1);
    return charArray;
   
		
  
}

int partition(unsigned char a[], int l, int r) {
   unsigned char x = a[l];
   int j = l;
   unsigned char temp;
  
   for (int i = l + 1; i <= r; i++) {
     if (a[i] >= x) {
       j++;
       temp = a[i];
       a[i] = a[j];
       a[j] = temp;
     }
   }
   temp = a[l];
   a[l] = a[j];
   a[j] = temp;

   return j;

}
void quick_sort(unsigned char charArray[], int l, int r) {
   if (l >= r) {
     return;
   }
   unsigned char temp;
   int k;
    k = l + ((r - l) / 2) ;
 
   temp = charArray[l];
   charArray[l] = charArray[k];
   charArray[k] = temp;
   int m = partition(charArray, l, r);


   quick_sort(charArray, l, m - 1);
   quick_sort(charArray, m + 1, r);
}




//find median value of a sorted array 
//the input is a sorted array and its length
//the return value -- array median
unsigned char find_median(unsigned char charArray[], int length){
   


   //if array is even find the mean between the two middle indexes
   // of the sorted array
   unsigned char charTemp;
   int intTemp = length/2;
   
   if(!(length % 2)){
        charTemp = charArray[intTemp] + charArray[intTemp - 1]; 
        charTemp /= 2;    
         
   }
    //find middle value of an odd array
   else
      charTemp =  charArray[intTemp - 1];;

   return charTemp;
}
               


//finds the maximum value of a sorted array
//input - a sorted array desending order and its length
//return value -- array maximum
unsigned char find_maximum(unsigned char charArray[], int length){
   
    return charArray[0];
                           
                      
} 
               
//finds the minimum value of a sorted array
//input is an array in desending order and its length
//return value--array min
unsigned char find_minimum(unsigned char charArray[], int length){
    
    return charArray[length - 1];


}               
               
//calculates the mean value (standard average) of the array
//input array and its length
//returns the mean value of all the intergers in the array
unsigned char find_mean(unsigned char charArray[], int length){
    int total =  0;  
   if(length!= 0){
      for(int i = 0; i < length; i++){
         total += charArray[i];
      }
      total /= length;
   }
   return (unsigned char) total;

} 

//input array stastics -- min, max, mean, median, all char
//output print all to console-no return value


//print array
//input array output printed array to console
//output print all to console-no return value







