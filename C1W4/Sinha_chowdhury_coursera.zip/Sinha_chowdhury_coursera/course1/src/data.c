

///////////////////data.c file///////////////////////////

/******************************************************************************
 * Copyright (C) 2017 by William Hays  Coursera course
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this software as they see fit.  
 * William Hays are not liable for any misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file data.c
 * @brief the is a basic data manipulation file for ascii to int
 * or int to ascii conversion
 * The implementation of this file provides the utilities need for 
 * other applications
 *
 *
 * @author William Hays
 * @date Aug 23, 2018
 *
 */
 #include "../include/common/data.h"
 
 
#include <stdio.h>

#include <stdlib.h>
 
 
 /*  This function is to convert any base ranging from 2 - 16
	 from a series of ascii digits to a base 10 interger 
 
 */

int32_t my_atoi( uint8_t *ptr,uint8_t digits,  uint32_t base){
	
	
	uint8_t *end =NULL;
	
	//save the ptr address by creating an index ptr
 	uint8_t  *indexPtr = ptr;
    end = ptr + digits - 1;
	
	//check for neg sign
	int neg = 0;  //default non neg
	if((*ptr) == '-'){
		neg = 1;
		indexPtr++;
	}

	 //each digit will be its value times base to the power of its position;
	int digitPos = 1;  //location of digit for its base power
	char digit;    //for each asci char in mem
	int mult = 1;  //position multplier for base
	int32_t accumulator = 0;  //summer of the ascii digits
	uint32_t asciiToInt = 0;  //int after conv ascii value
   //this converts any base from 2 to 16 in ascii to base 10 interger	
	while( end >= indexPtr ){  
		
		asciiToInt =0;
		digit = *end;
		
	//convert ascii to int
		if(digit <= '9' && digit >= '0')
		    asciiToInt = digit - 48;
		else if (digit == 'A' || digit == 'a')
			asciiToInt = 10;
		else if (digit == 'B' || digit == 'b')
			asciiToInt = 11;
		else if (digit == 'C' || digit == 'c')
			asciiToInt = 12;
		else if (digit == 'D' || digit == 'd')
			asciiToInt = 13;	
		else if (digit == 'E' || digit == 'e')
			asciiToInt = 14;
		else if (digit == 'F' || digit == 'f')
			asciiToInt = 15;	
	
		mult = 1;			
		for (int j = 1; j < digitPos; j++){//we can't use a library
				mult = mult * base;			
			} 
			
		accumulator += (mult *  asciiToInt);	 
		digitPos++;
		end--;
				   
	}
			
		if(neg == 1)
			accumulator = -accumulator;
	
	 	return accumulator;
} 

/*
  this will conver each number passed in as data to ifs
  ascii equavalent in base 10 
  data is the number and base is numeric base
  the pointer ptr will point to the ascii string
  generated

*/


 uint8_t my_itoa(int32_t data, uint8_t *ptr, uint32_t base){

	 
	 //the maximum digit size is 10 digits for a 32 bbit number
	 int32_t  dividend = data;
	 int neg = 0;
	 uint8_t *digitEndPos =0;
	 uint8_t digitCount = 0;
	int digitPos = 0;
	 //if the interger is negative the MSD will be 1
	 if(0x80000000 & dividend) {
		neg = 1; 	
		dividend = ~(data);
		//add 1
		dividend += 1;
	 }
	int32_t digiCounterData = dividend;
  
	 while(digiCounterData  >= 1){
	
		digitPos++;
		digiCounterData  /= 10;
	 }
		
	 /*****************************************************
	 to create memory for a 32 bit ascii represented
	 interger requires a possible 10 digits plus one space
	 for the terminating null character and a minus sign 
	 if their is one 
	 ********************************************************/
	 
     uint8_t  *tempPtr = (uint8_t*) malloc ( digitPos * sizeof(uint8_t) + neg + 1);
	 digitEndPos   = (tempPtr + digitPos * sizeof(uint8_t) + 1 + 1 );
	 
	 
	 //Put a null pointer at the end
	 //and move back one
	 *(digitEndPos ) = '\0';
	 digitEndPos--;
	 digitCount++;
     //to preserve the original data
	 
	 //digit counter
    
	char asciiChar ;
	
	
	/*
	    as long as the ruduce number 
		by repeated division is larger than the
		base number the loop will continue
	*/
	//save the conveted number
     digiCounterData = dividend;
	 int32_t  digit  = 0;
	 while(dividend  >= 1){  
		
		
		digit = dividend  % base;
		dividend  /=  base;
	
	  //up to base 16
		if(digit >= 10  && digit < 16){
			
			if (digit == 10)
				asciiChar = 'A';
			else if (digit == 11)
				asciiChar =  'B';
			else if (digit == 12)
				asciiChar = 'C';
			else if (digit == 13)
				asciiChar = 'D';	
			else if (digit == 14)
				asciiChar = 'E';
			else if (digit == 15)
				asciiChar = 'F';	
		
		}else if(digit <10  && digit >= 0)
		asciiChar = digit + 48;
	
		*digitEndPos = asciiChar;	
	
		digitCount++;
		digitEndPos--;
	}
	if(neg){
		
		
		digitCount++;
		digitEndPos--;
		*digitEndPos  = '-';
	}
 	for(int i = 0;  i <= digitCount; i++){
		*ptr++ = *digitEndPos++;
		
	}
	
	free(tempPtr); 
	
	return digitCount  ;
 }

	
	
	
     
void print_array(uint8_t *charArray, size_t length){
   int i = 0;
   
   
    printf( "%s", ": \n");
   printf("%s", "\n    ");
   for(int i = 0; i < length; i++){
       if(i  == 4){
        
          printf("%i %s", charArray[i], " ");
          printf("%s", "\n    ");
       }
       else if( i % (4 + 1) == 0 && i > 5){
         printf("%s", "\n    ");
         
         printf("%i %s", charArray[i], " ");
          getSpacing(charArray[i]);
       }
       else{
         
         printf("%i %s", charArray[i], " ");
        getSpacing(charArray[i]);
       }  
   }
    printf("%s", "\n\n");
    printf("%s", "\n\n");
 }


//function to determine and print spaces needed  
//lines up columns based on the number of digits
void getSpacing(uint8_t inChar){
   if(inChar < 10)
     printf("%s",  "  ");
   else if(inChar < 100)
     printf("%s", " ");
   else      
     return;
}

	
 
 
 
 
