





#include     "../include/common/printfile.h"


void print_array(uint8_t *charArray, size_t length,  char* passedInText){
   int i = 0;
   printf( "%s", "  To follow is the array " );
   while(*(passedInText + i)){
	   printf("%c", (*(passedInText + i))); i++;
   }
    printf( "%s", ": \n");
   printf("%s", "\n    ");
   for(int i = 0; i < length; i++){
       if(i  == 4){
        
          printf("%i %s", charArray[i], " ");
          printf("%s", "\n    ");
       }
       else if( i % (4 + 1) == 0 && i > 5){
         printf("%s", "\n    ");
         
         printf("%i %s", charArray[i], " ");
          getSpacing(charArray[i]);
       }
       else{
         
         printf("%i %s", charArray[i], " ");
        getSpacing(charArray[i]);
       }  
   }
    printf("%s", "\n\n");
    printf("%s", "\n\n");
 }


//function to determine and print spaces needed  
//lines up columns based on the number of digits
void getSpacing(uint8_t inChar){
   if(inChar < 10)
     printf("%s",  "  ");
   else if(inChar < 100)
     printf("%s", " ");
   else      
     return;

}

