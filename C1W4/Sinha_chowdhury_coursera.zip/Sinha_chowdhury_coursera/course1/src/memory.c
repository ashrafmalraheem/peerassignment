/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file memory.c
 * @brief Abstraction of memory read and write operations
 *
 * This implementation file provides an abstraction of reading and
 * writing to memory via function calls. There is also a globally
 * allocated buffer array used for manipulation.
 *
 * @author William Hays
 * @date Aug 23, 2018
 *
 */


#include "../include/common/memory.h"


/***********************************************************
 Function Definitions
***********************************************************/
void set_value(char * ptr, unsigned int index, char value){
  ptr[index] = value;
}

void clear_value(char * ptr, unsigned int index){
  set_value(ptr, index, 0);
}

char get_value(char * ptr, unsigned int index){
  return ptr[index];
}

void set_all(char * ptr, char value, unsigned int size){
  unsigned int i;
  for(i = 0; i < size; i++) {
    set_value(ptr, i, value);
  }
}

void clear_all(char * ptr, unsigned int size){
  set_all(ptr, 0, size);
}

/** 
 * This function moves memory from src to dsc.  the length of memory at
 * src is length.  Move means it will no longer exist in the source location
 * just as it does in file manager operations
 */
uint8_t *my_memmove(uint8_t *src, uint8_t *dst, size_t length){
	
	uint8_t *des_start;
	uint8_t *src_start;
    des_start = dst;
	src_start = src;
	
	// make sure there is not overlap
	if(src < dst && (src + length) > dst) {
	  while( src < des_start){
			
		     *dst++ = *src++; 
		
		}
		dst = src_start;
	 }
	 else if(src > dst && (dst + length) > src){
		 src  = dst + length;
		 while(src < src_start ) {
			    *dst++ = *src++; 
		 }	  
		dst = des_start;		 
	 }
	 else {
		 while(src < src_start + length)  {
			     *dst++ = *src++; 
			   
		 }
		 dst = des_start;
	 } 

		//return pointer to start of dst
	return dst;
}


/*
 * This function copies memory from src to dsct  the length of memory at
 * src is length.
 */
 //pointers are copied by value--point to memory locations
uint8_t *my_memcopy(uint8_t *src, uint8_t *dst, size_t length){
	
    uint8_t *des_start;
	uint8_t *src_start;
    des_start = dst;
	src_start = src;
	
	// make sure there is not overlap
	if(src < dst && (src + length) > dst) {
	  while( src < des_start){
			
		     *dst++ = *src++; 
		
		}
		dst = src_start;
	 }
	 else if(src > dst && (dst + length) > src){
		 src  = dst + length;
		 while(src < src_start ) {
			    *dst++ = *src++; 
		 }	  
		dst = des_start;		 
	 }
	 else{
		 while(src <= src_start + length)  {
			     *dst++ = *src++; 
			   
		 }
		 dst = des_start;
	 } 

		//return pointer to start of dst
	return dst;

}



///*
 //* This function sets all memory elements to value passed in
 //* src is length.
 //*
 //pointers are copied by value--point to memory locations
uint8_t *my_memset(uint8_t *dst, size_t length, uint8_t value){

	uint8_t *start = dst;
		while(dst < start + length){
			
		     *dst++ = value;			 
			 	  
		}
		
	return start;
}

///*
 //* This function sets all memory elements to zero
 //*length is size of the meomory location
 //*
 //pointers are copied by value--point to memory locations
uint8_t *my_memzero(uint8_t *dst, size_t length){

	
	uint8_t *index = dst;
		while(index < dst + length){
			
			*(index) = 0;
			index++;	 
		}
		
	return dst;
}


///*
 //* This function reverses the elements in memory
 //*length is size of the meomory location
 //* This is a byte by byte (smallest unit) reversal
 //pointers are copied by value--point to memory locations
uint8_t *my_reverse(uint8_t *dst, size_t length){

	    uint8_t *start;
		uint8_t tempValue;
		start = dst;
	    
		for(uint8_t *index = dst + length  -1;  index > dst; ){
			
			tempValue = *dst;			
			*dst = *index;
			*index = tempValue;
			dst++;
			index--;
				 
		}
		
	return start;
}

/*
 * This function reverses the elements in memory
 * length is size of the meomory location
 * This is the same as the function abouve except this
 * reverses words (32 bit) while the function above'
 * reverses byte by byte
 * pointers are copied by value--point to memory locations
 */



int32_t *reserve_words(size_t length){
     
	int32_t *ptr = (int32_t*)  malloc(length * sizeof(int32_t));
	if(!ptr)
		return NULL;

		
	
	return ptr;
}
void free_words(int32_t *src){

	  free( src);
	
}


void free_words8(uint8_t *src){

	  free( src);
	
	
}














