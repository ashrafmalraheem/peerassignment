

/**
 * @file Printfile.h
 * @brief Abstraction of print function to display test results
 *
 * This header file provides an abstraction of reading and
 * writing to printing  via function calls. 
 *
 * @author William Hays
 * @date Aug 23, 2018
 *
 */
 


 
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


 void print_array(uint8_t *charArray, size_t length,  char* passedInText);
 void getSpacing(uint8_t inChar);