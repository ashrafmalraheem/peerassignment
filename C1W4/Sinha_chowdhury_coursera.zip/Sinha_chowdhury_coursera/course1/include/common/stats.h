/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file <stats.h> 
 * @brief <h file for a program to calculate stastics of an array>
 *
 * <Add Extended Description Here>
 *
 * @author <William Hays>
 * @date <Aug 4, 2018>
 *
 */
#ifndef __STATS_H__
#define __STATS_H__
#include  <stdint.h>
/* Add Your Declarations and Function Comments here */ 



/////////sorting section////////////////////
unsigned char *sort_array(unsigned char charArray[], int length);
/**
 * @brief <sorts an array in desending order by calling quicksort>
 *
 * @param <charArray> <unsigned character array>
 * @param <length> <length of the array>
 *
 * @return <returns a pointer to a sorted array>
 */


int partition(unsigned char a[], int l, int r);
/**
 * @brief <partition an array for sort an array>
 *
 * @param <charArray> <array of unsingned characters>
 * @param <left array value l> <length of the array>
 * @param <right array value r> <length of the array>
 * @return <returns an int index of arrray>
 */


void quick_sort(unsigned char charArray[], int l, int r) ;
/**
 * @brief <part of quick_sort algorithm to sort an array>
 *
 * @param <charArray> <array of unsingned characters>
 * @param <left array value l> <length of the array>
 * @param <right array value r> <length of the array>
 * @return <has no return value>
 */

////////////end of sorting section /////////////////////////


//////////////////stistical functions///////////
unsigned char find_median(unsigned char array[], int length);
/**
 * @brief <finds the median value of a sorted array>
 *
 * @param < charArray> <array of unsingned characters>
 * @param <length> <length of the array>
 *
 * @return <returns median value of the array>
 */


unsigned char find_maximum(unsigned char charArray[], int length);
/**
 * @brief <finds the maximum value of a desending sorted array>
 *
 * @param < charArray> <array of unsingned characters>
 * @param <length> <length of the array>
 *
 * @return <returns maximum value of the array>
 */


unsigned char find_minimum(unsigned char charArray[], int length);
/**
 * @brief <finds the minimum value of a desencing sorted array>
 *
 * @param < charArray> <array of unsingned characters>
 * @param <length> <length of the array>
 *
 * @return <returns minimum value of the array>
 */


unsigned char find_mean(unsigned char array[], int length);
/**
 * @brief <finds the mean value of an array>
 *
 * @param < charArray> <array of unsingned characters>
 * @param <length> <length of the array>
 *
 * @return <returns mean value of the array>
 */
////////////////////end of stistical functions ///////////////////


//////////////////////printing functions (console output)///////////////////


#endif /* __STATS_H__ */
