


////////////////////////data.h/////////////////////////////////

#ifndef __DATA_H__
#define __DATA_H__



#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


/*

 * @brief Sets an interger value to its ascii counterpart
 *
 * it convers a signed 32 bit interger to an ascii string
 * this function will handle any base from 2 to 16
 *
 * maximum number is -2^(32-1) to 2^(32-1) -1
 * @param ptr Pointer to data array
 * @param index Index into pointer array to set value
 * @param base the base passed in from 2 to 16
 *
 * @return ascii value.
 */


uint8_t my_itoa(int32_t data, uint8_t *ptr, uint32_t base);


/*

 * @brief Converts an ascii input to its interger representation
 *
 * it converts an ascii value to an interger
 * index into that data set to the value provided.
 * this function will handle any base from 2 to 16
 * @param ptr Pointer to data array
 * @param index Index into pointer array to set value
 * @param value value to write the the locaiton
 *
 * @return a 32 bit interger
 */
int32_t my_atoi( uint8_t *ptr,uint8_t digits,  uint32_t base);






void  print_stastics(int min, int max, int mean, int median);
/**
 * @brief <prints calculated and found values from an array>
 *
 * @param < min> <min value of the array>
 * @param < max> <max value of the array>
 * @param < mean> <mean value of the array>
 * @param < median> <median value of the array>
 *
 * @return <has no return value>
 */
  


/**
 * @brief <print spaces to line up digits in an array>
 *
 * @param <inChar> <number to evaluate for number of spaces based
 *                   on its number of digits>
 *
 * @return <has no return value>
 */
void getSpacing(uint8_t inChar);

 
 



/**
 * @brief <print an array>
 *
 * @param <charArray> <array of unsingned characters>
 * @param <length> <length of the array>
 *
 * @return <has no return value>
 */


 void print_array(uint8_t *charArray, size_t length);




#endif